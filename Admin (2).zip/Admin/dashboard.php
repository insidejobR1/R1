<?php
session_start();
// if session not set so start a session
// if(!isset($_SESSION)) // yani seesion set hoga to hi session start hoga varna nhi hoga
// { 
//   session_start(); 
// } 

//Checking Session
require_once('session_check.php');

$id = "";

include('index.php');

// include database
include ('config1.php');

// Get Review count
// Total Customer Record of register table
$sql = "select * from reg_tb  ";
$total_reg_tb  = mysqli_query($con,$sql);
$all_reg_tb = mysqli_num_rows($total_reg_tb);
     
 //geting Review total today register
 $total_today_reg_tb = mysqli_query($con,"select * from reg_tb where 'date' >= DATE_SUB(CURDATE(), INTERVAL 1 Day)");
 //var_dump($today_all_review);
 $today_all_review = mysqli_num_rows($total_today_reg_tb);


// login id pass by session
$id = $_SESSION['id']; 
// chack the user ampount 
$query = "SELECT amount FROM user_account WHERE id= '$id'";
$result = mysqli_query($con,$query);
$present_amount = mysqli_num_rows($result);
// check the condition 
if($present_amount > 0)
{
    $row = mysqli_fetch_array($result);
    $total_amount = $row['amount']; // my carrent amount deposit
}
else
{
  $total_amount= 0;
}

// Total Customer Record of register table
$sql = "select * from register_tb  ";
$res = mysqli_query($con,$sql);
      
$row = mysqli_num_rows($res);
      
      //echo $row;// serial Number
     
      if($row >0)
      {
          echo "total<br>". $row;
        
      }


?>

<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Tailwind Css -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.tailwindcss.com?plugins=forms,typography,aspect-ratio,line-clamp"></script>
  
    <script src="https://kit.fontawesome.com/63f9d3355b.js" crossorigin="anonymous"></script>

  <!-- css -->
  <style type="text/css">

    .panel{
      width: 100vw;
      height: 100vh;
      /* background: black; */
    }

    .head{
      width: 100vw;
      height: 12vh;
      /* background: #999; */
    }

    .sidebar{
      width: 15vw;
      height: auto;
      /* background: #f7f7f7; */
      float: left;
    }

    .content{
      float: right;
      width: 82vw;
      height: auto;
    }

  </style>

  <title>Dashboard</title>
</head>
<body>
  <div class="panel">

    <!-- NAVIGATION -->
    <div class="head">
      <header class="text-gray-600 body-font">
        <div class="container mx-auto flex flex-wrap p-5 flex-col md:flex-row items-center">
          <a class="flex title-font font-medium items-center text-gray-900 mb-4 md:mb-0">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-10 h-10 text-white p-2 bg-indigo-500 rounded-full" viewBox="0 0 24 24">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
            </svg>
            <span class="ml-3 text-xl">Capital Octa</span>
          </a>
          <nav class="md:ml-auto flex flex-wrap items-center text-base justify-center">
            <a class="mr-5 hover:text-gray-900">First Link</a>
            <a class="mr-5 hover:text-gray-900">Second Link</a>
            <a class="mr-5 hover:text-gray-900">Third Link</a>
            <a class="mr-5 hover:text-gray-900">Fourth Link</a>
          </nav>
          <button class="inline-flex items-center bg-gray-100 border-0 py-1 px-3 focus:outline-none hover:bg-gray-200 rounded text-base mt-4 md:mt-0">Button
            <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-4 h-4 ml-1" viewBox="0 0 24 24">
              <path d="M5 12h14M12 5l7 7-7 7"></path>
            </svg>
          </button>
        </div>
      </header>
    </div>

    <!-- SIDEBAR -->
    <div class="sidebar">
      <div class="flex-col w-full md:flex md:flex-row md:min-h-screen bg-blueGray-50">
        <div class="flex flex-col flex-shrink-0 w-full text-blueGray-700 bg-white shadow-xl md:w-64">
          <div class="flex flex-col items-center flex-shrink-0 bg-blueGray-50">
            <button class="p-1 m-2 ml-auto transition-colors duration-200 transform rounded-md hover:bg-opacity-25 hover:bg-blueGray-600 focus:outline-none" type="button" aria-label="Close" aria-hidden="true">
              <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-circle-x" width="24" height="24" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                <circle cx="12" cy="12" r="9"></circle>
                <path d="M10 1014 4m0 -41-4 4"></path>
              </svg>  
            </button>
          </div>
          <div class="flex flex-col items-center flex-shrink-0 pb-4 bg-blueGray-50">
            <img alt="testimonial" class="inline-block object-cover object-center w-20 h-20 mb-8 bg-blueGray-100 rounded-full" src="https://dummyimage.com/302x302/F3F4F7/8693ac" />
            <h2 class="text-sm font-medium tracking-widest text-black uppercase title-font">Ajay Nandal</h2>
            <p class="text-blueGray-500">Front-End Developer</p>
          </div>
          <nav class="flex-grow pb-4 pr-4 md:block md:pb-0 md:overflow-y-auto">
            <ul>
              <li>
                <a href="#" class="block px-4 py-2 mt-2 text-base text-blueGray-500 transition duration-500 ease-in-out transform border-1-4 border-blue-600 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 hover:text-black">Price</a>
              </li>

              <li>
                <a href="#" class="block px-4 py-2 mt-2 text-base text-blueGray-500 transition duration-500 ease-in-out transform border-1-4 border-blue-600 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 hover:text-black">Contact</a>
              </li>

              <li>
                <a href="#" class="block px-4 py-2 mt-2 text-base text-blueGray-500 transition duration-500 ease-in-out transform border-1-4 border-blue-600 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 hover:text-black">Service</a>
              </li>

              <li>
                <a href="#" class="block px-4 py-2 mt-2 text-base text-blueGray-500 transition duration-500 ease-in-out transform border-1-4 border-blue-600 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 hover:text-black">Services</a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>

    <!-- DASHBOARD-CONTENT -->
    <div class="content">
    <?php
// session display and unset code
//if(isset($_SESSION['success']) || isset($_SESSION['status']))
if(isset($_SESSION['success']))
{
  echo "<h3> ".$_SESSION['success']. "</h3>";
  unset($_SESSION['success'] ); // sesstion unset
}
elseif(isset($_SESSION['status']))
{
  echo "<h3> ".$_SESSION['status']. "</h3>";
  unset($_SESSION['status'] ); // sesstion unset
}

?>

    <section class="text-gray-600 body-font">
      <div class="container px-5 py-24 mx-auto">
        <div class="flex flex-col text-center w-full mb-20">
          <h1 class="sm:text-3xl text-2xl font-medium title-font mb-4 text-gray-900">Master Cleanse Reliac Heirloom</h1>
          <p class="lg:w-2/3 mx-auto leading-relaxed text-base">Whatever cardigan tote bag tumblr hexagon brooklyn asymmetrical gentrify, subway tile poke farm-to-table. Franzen you probably haven't heard of them man bun deep jianbing selfies heirloom prism food truck ugh squid celiac humblebrag.</p>
        </div>
        <div class="flex flex-wrap -m-4 text-center">
          <div class="p-4 md:w-1/4 sm:w-1/2 w-full">
            <div class="border-2 border-gray-200 px-4 py-6 rounded-lg">
              <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="text-indigo-500 w-12 h-12 mb-3 inline-block" viewBox="0 0 24 24">
                <path d="M8 17l4 4 4-4m-4-5v9"></path>
                <path d="M20.88 18.09A5 5 0 0018 9h-1.26A8 8 0 103 16.29"></path>
              </svg>
              <h2 class="title-font font-medium text-3xl text-gray-900"> Total Customer<br> <?php  echo $all_reg_tb;?></h2>
              <p class="leading-relaxed">Downloads</p>
            </div>
          </div>
          <div class="p-4 md:w-1/4 sm:w-1/2 w-full">
            <div class="border-2 border-gray-200 px-4 py-6 rounded-lg">
              <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="text-indigo-500 w-12 h-12 mb-3 inline-block" viewBox="0 0 24 24">
                <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
                <path d="M23 21v-2a4 4 0 00-3-3.87m-4-12a4 4 0 010 7.75"></path>
              </svg>
              <h2 class="title-font font-medium text-3xl text-gray-900">Today Customer <br> <?php  echo $today_all_review;?></h2>
              <p class="leading-relaxed">Users</p>
            </div>
          </div>
          <div class="p-4 md:w-1/4 sm:w-1/2 w-full">
            <div class="border-2 border-gray-200 px-4 py-6 rounded-lg">
                <i class="fa-solid fa-filter-circle-dollar"></i>
              <!--<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="text-indigo-500 w-12 h-12 mb-3 inline-block" viewBox="0 0 24 24">-->
              <!--  <path d="M3 18v-6a9 9 0 0118 0v6"></path>-->
              <!--  <path d="M21 19a2 2 0 01-2 2h-1a2 2 0 01-2-2v-3a2 2 0 012-2h3zM3 19a2 2 0 002 2h1a2 2 0 002-2v-3a2 2 0 00-2-2H3z"></path>-->
              <!--</svg>-->
              <h2 class="title-font font-medium text-3xl text-gray-900">Customer Fund <br> <?php  echo $total_amount;?></h2>
              <p class="leading-relaxed">Files</p>
            </div>
          </div>
<!--          <div class="p-4 md:w-1/4 sm:w-1/2 w-full">-->
<!--            <div class="border-2 border-gray-200 px-4 py-6 rounded-lg">-->
<!--              <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="text-indigo-500 w-12 h-12 mb-3 inline-block" viewBox="0 0 24 24">-->
<!--                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>-->
<!--              </svg>-->
<!--              <h2 class="title-font font-medium text-3xl text-gray-900">-->
<!--                  <ul>-->
<!--    <li style="color:black;">7 Days</li>-->
<!--    <li style="color:black;">Month</li>-->
<!--    <li style="color:black;">3 Month</li>-->
<!--    <li style="color:black;">6 Month</li>-->
<!--</ul>-->

<!--              </h2>-->
<!--              <p class="leading-relaxed">Places</p>-->
<!--            </div>-->
<!--          </div>-->
        </div>
      </div>
    </section>
    </div>
  </div>
  <?php //session_unset();?>
</body>
</html>