<?php
// if session not set so start a session
if(!isset($_SESSION)) // yani seesion set hoga to hi session start hoga varna nhi hoga
{ 
  session_start(); 
} 
//Checking Session
require_once('session_check.php');

$id = "";
// include database Show User Detail 
include ('config1.php');

// /// traansection
// // Turn off error reporting
// error_reporting(0);
// // last date 
// $from_date = $_GET['from_date'];
// // current date
// $to_date = $_GET['to_date'];
// // user table se created_at name ke time se late day se today tk ka data find kiya 
// //$query = "SELECT * FROM users WHERE created_at BETWEEN '$from_date' AND '$to_date' ";
// $query = "SELECT * FROM user_account WHERE date BETWEEN '$from_date' AND '$to_date' ";
// $query_run = mysqli_query($con, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="sy.css">
</head>
<body>
    
  
    <!-- Deposit data-->
<div class="container">
<table class="table" >
  <thead class="thead-dark">
    <tr>
      <th scope="col">S.No.</th>
      <th scope="col">Amount</th>
      
      <th scope="col">Date</th>
    </tr>
  </thead>
  <tbody>
      <?php
      
    $sql = "select * from user_account";
      $res = mysqli_query($con,$sql);
      
      $row = mysqli_num_rows($res);
      
      echo $row;
     
      if($row >0)
      {
          //echo $row;
          while($ro = mysqli_fetch_assoc($res))
          { 
              $id = $ro['id'];
             // $name = $ro['name'];
              $amount = $ro['amount'];
            //   $email = $ro['email'];
            //   $pass = $ro['pass'];
            //   $add = $ro['addres'];
            //   $pan = $ro['pancard'];
            //   $adc = $ro['adharcard'];
              $date = $ro['date'];
              
              echo '<tr>
              <th scope="row">'.$id.'</th>
              <td>'. $amount.'</td>
            //  <td>'. $num.'</td>
            //   <td>'. $email.'</td>
            //   <td>'. $pass.'</td>
            //   <td>'. $add.'</td>
            //   <td>'. $pan.'</td>
            //   <td>'. $adc.'</td>
              <td>'. $date.'</td>
            
           </tr> ';
     
          }
        }
      

      ?>
    
  </tbody>
</table>
</div>

</body>
</html>