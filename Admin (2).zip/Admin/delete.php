<?php
include 'config1.php';

if(isset($_GET['deleteid'])) // indentify define
{
$id = $_GET['deleteid'];
$sql= "DELETE FROM register_tb where id='$id' ";
$res = mysqli_query($con,$sql);


//if(isset($_POST[''])) // if button click
if($res)
{
    echo " Data Delete Successfully";
}
else
{
    echo " error";
}

}
mysqli_close($con);

?>