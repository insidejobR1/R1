<?php
// start session
session_start();
// define session variable
$msg = "";
// sset condition a session
if(isset($_SESSION['alert']))
{
  // Decalear variable
  $msg = "Not Enough Money in Your Bank Account";
}
// include master page 
include('master.php'); 

?> 

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
  <title>Transfer</title>
<!-- Bostrap css -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
   <!-- css -->

   <style>
     .panrl{
       position: relative;
     }

     .login{
       position: absolute;
       top: 50%;
       left: 50%;
       transform: translate(-50%,-50%);
     }

   </style>
  
</head>
<body>

<div class="container">
  
<form class="login" action="code.php" method="POST">
  <!-- Session Desplay -->
<h1>Transfer Money</h1>
   <div class="form-group text-center">
    <label for="exampleInputNumber">Enter Sending Amount</label>
    <input type="float" class="form-control" name="number" id="exampleInputNumber" placeholder="Enter Amount">
  </div>
  <div class="form-group text-center">
    <label for="exampleInputEmail">Enter Receiver Email</label>
    <input type="email" class="form-control" name="remail" id="exampleInputEmail" placeholder="Enter Email">
  </div>
 
   <button type="submit" name="transfer" class="btn btn-primary col-lg">Transfer</button>
  <p style="font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; font-size:small; text-align:center; color:cadetblue;">Amount Should be RS.</p>
</form>
  </div> 
  <!-- Seesion Unser / Destroy -->
  <?php unset($_SESSION['alert']);?>
</body>
</html>