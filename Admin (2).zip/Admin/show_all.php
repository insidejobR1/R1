<?php
// if session not set so start a session
if(!isset($_SESSION)) // yani seesion set hoga to hi session start hoga varna nhi hoga
{ 
  session_start(); 
} 
$id = "";
//Checking Session
//require_once('session_check.php');

// include database Show User Detail 
include ('./config2.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="sy.css">
    
    <Style>
    .table-scroll{
        width: 80%;
        height: 95vh;
        overflow-y: auto;
        margin: 0 0 0 19rem;
    }
        td, th {
          border: 1px solid #dddddd;
          text-align: left;
          padding: 8px;
        }
        table{
         border-collapse: collapse;
         width: 100%;
        }
        .top-tr{
           background: #0061f7;
           color: #fff;
        }
        tr:nth-child(even){
            background-color: #dddddd;
        }
        
    </Style>
</head>
<body>
    
<div class="container table-scroll">
    <div class="row">
        <div class="col-lg-8">
<table class="table" >
  <thead class="thead-dark">
    <tr class="top-tr">
      <th scope="col">S.No.</th>
      <th scope="col">User Name</th>
      <th scope="col">Number</th>
      <th scope="col">Email</th>
      <th scope="col">Password</th>
      <th scope="col">Address</th>
      <th scope="col">Pancard</th>
      <th scope="col">Adharcard</th>
      <th scope="col">Date</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
      <?php
      
    $sql = "select * from register_tb";
      $res = mysqli_query($con,$sql);
      
      $row = mysqli_num_rows($res);
      
      echo $row;
     
      if($row >0)
      {
          //echo $row;
          while($ro = mysqli_fetch_assoc($res))
          { 
              $id = $ro['id'];
              $name = $ro['name'];
              $number = $ro['number'];
              $email = $ro['email'];
              $pass = $ro['pass'];
              $add = $ro['address'];
               $pan = $ro['pancard'];
               $adc = $ro['adharcard'];
              $date = $ro['date'];
              
              echo '<tr>
              <th scope="row">'.$id.'</th>
               <td>'. $name.'</td>
              <td>'. $number.'</td>
              <td>'. $email.'</td>
              <td>'. $pass.'</td>
              <td>'. $add.'</td>
              <td>'. $pan.'</td>
             <td>'. $adc.'</td>
              <td>'. $date.'</td>
              <td>
              &nbsp;&nbsp;&nbsp;
               <a href="update.php?updateid='.$id.'" class=" btn btn-primary btn-sm text-light">Update</a>
              &nbsp;
    
              <a href="delete.php?deleteid='.$id.'" class=" btn btn-primary btn-sm text-light">Delete</a>
             
              </td>
            
           </tr> ';
     
          }
        }
      

      ?>
    
  </tbody>
</table>
</div>
</div>
</div>
</body>
</html>