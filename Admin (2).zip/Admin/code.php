<?php
// start session
session_start();
// include database
include ('db_connect.php');

//1. Your Sign Up Page////////////////////////////////////
if(isset($_POST['reg']))
{
 // define and declayer variable / assisgn a input value in variable
  $email = $_POST['email'];
  $password = $_POST['pass'];
  $confirm_password = $_POST['confirmpass'];

 // password match or not match condition
 if($password === $confirm_password)
 {
     // inser query
     $query = "INSERT INTO register_tb (email,pass) VALUES ('$email','$password')";
     // pass the connection and query in mysqli query 
     $query_run = mysqli_query($con, $query);   
     
     // check data insert or not
     if($query_run)
     { 
         
         // display msg
         echo "<h4>Successfully Done</h4>";
         // create a session variable
        $_SESSION['success'] =  " SignUp Successfully";
        // page location
         header('Location:index.php');
     }
     else 
     {
         echo "<h4> SignUp Failed </h4>";
         $_SESSION['status'] =  "SignUp Failed "; // assing the value of variable
         header('Location:index.php');
         die (mysqli_connect_error($con));
     }
 }
 else 
 {
     echo "<h4>Password not Match </h4>";
     $_SESSION['status'] =  "Password and Confirm Password Does not Match";
     header('Location: index.php');
     die (mysqli_connect_error($con));
 }

}

//2. Login Query////////////////////
if(isset($_POST['log']))
{
$email = $_POST['email'];
$pass = $_POST['pass'];

$sql = "select * from register_tb where email='$email' and pass='$pass'";
$result = mysqli_query($con,$sql);
$present = mysqli_num_rows($result);
// chack the condition 
if($present >0)
{
  $query = "select id from register_tb where email = '$email' and pass = '$pass'";
  $result = mysqli_query($con,$query);
  $row = mysqli_fetch_array($result);
  //$id = $row['id'];
  $_SESSION['id'] = $row['id'];
  echo "<h2> ID is ".$id."</h2>";
    echo " Correct User";
    header('Location:index.php');
    exit();
}
else
{
    echo " incorrect User ID and Password";
    die(mysqli_error($con));
}
}


// 3. Cash Deposit Query///////////////////////////////
if(isset($_POST['add']))
{
 //echo "Hello firends";
 // insert amount
 $money = $_POST['number'];
 // if user login and deposit amount so last amount and carrent amont add query
 // login id pass by session
 $id = $_SESSION['id']; 
 // chack the user ampount 
 $query = "SELECT amount FROM user_account WHERE id= '$id'";
 $result = mysqli_query($con,$query);
 $present_amount = mysqli_num_rows($result);
 // check the condition 
 if($present_amount > 0)
 {
     $row = mysqli_fetch_array($result);
     $deposit = $row['amount']; // my carrent amount deposit
     $total_amount = $deposit + $money; // add last amount and carren t amount
     // show data my add data last amount and current amount
     $querys = "UPDATE user_account SET amount = '$total_amount' where id = '$id' ";
     $result = mysqli_query($con,$querys);
     $_SESSION['success'] =  "Amount is Update Successfully";
     header("location:index.php");
 }
 else
 {
     // inser query only insert amount
     $query = "INSERT INTO user_account (id,amount) VALUES ('$id','$money')";
     // pass the connection and query in mysqli query 
     $query_run = mysqli_query($con, $query);   
     
     // check data insert or not
     if($query_run)
     { 
         // display msg
         echo "<h4>Successfully Done</h4>";
         // create a session variable
        $_SESSION['success'] =  "Amount is Added Successfully";
        // page location
         header('Location:index.php');
     }
     else 
     {
         echo "<h4> User Addition Failed </h4>";
         $_SESSION['status'] =  "Amount is Not Added"; // assing the value of variable
         header('Location:index.php');
         die (mysqli_connect_error($con));
     }
    }
}

//4. Cash Withdraw Query//////////////////////
if(isset($_POST['withdraw']))
{
 // withdraw amount
 $money = $_POST['number'];
// login id pass by session
 $id = $_SESSION['id']; 
 $sql = "SELECT amount from user_account where id = '$id'";
 $result = mysqli_query($con,$sql);
 $present_amount = mysqli_num_rows($result);

 // chack the my data In which row and colom 
 if($present_amount > 0)
 {   // fatch my data
     $row = mysqli_fetch_array($result);
     $total_amount = $row['amount'];
     // check the candition jo money nikal rhe h usse saving amount jyada h ya nhi
     if($total_amount > $money)
     {  
         // money withdraw
         $saving_amount = $total_amount - $money;
         // show data my add data last amount and current amount
         $querys = "UPDATE user_account SET amount = '$saving_amount' where id = '$id'";
         $result = mysqli_query($con,$querys);
        // echo $saving_amount;
         $_SESSION['success'] =  "Amount is Withdraw Successfully";
         //header("location:dashboard.php");
         header("location:index.php");

     }
     else
     {
        $_SESSION['alert'] =  "No Amount";
        header("location:withdraw.php");
    
     }

 }

}

// 5. Transfer Data//////////////////
if(isset($_POST['transfer']))
{
    $id = $_SESSION['id']; // pass by login user id / reg_tb id pas
    $money = $_POST['number'];
    $remail = $_POST['remail']; // reciver email
    // query for email  exist email or not exist in the regster table
    $sql = "SELECT * FROM register_tb where email = '$remail'";
    $result = mysqli_query($con,$sql);
    $present = mysqli_num_rows($result);
            if($present > 0 )
            {
                 //echo "Hello"." ".$remail;
                 // hamare account me amount h ya nhi h 
                 $sql = "SELECT amount FROM user_account where id = $id";
                 $result = mysqli_query($con,$sql);
                 $row_amount = mysqli_num_rows($result);
                 // if amount row present h to aye
                             if($row_amount > 0)
                             {
                                 $row = mysqli_fetch_array($result);
                                 $amount =$row['amount'];
                                // echo "Your amount is = ".$amount;
                                 // check the conddition amount greater h ya nhi money se
                                             if($amount > $money)
                                             {    // 1st id fatch form reg_tb
                                                $sql = "SELECT id FROM register_tb where email = '$remail'";
                                                $result = mysqli_query($con,$sql);
                                                $row1 = mysqli_fetch_array($result);
                                                $rid = $row1['id']; 
                                                // echo "id is = ".$rid;
                                                // fatch id from reg_tb pass the deposit table or reciver ki id se amount fatch
                                                $sql = "SELECT amount FROM user_account where id = '$rid'";
                                                $result = mysqli_query($con,$sql);
                                                $greater_amount = mysqli_num_rows($result);
                                                // echo "Greater amount is = ".$greater_amount;
                                                if($greater_amount > 0 )
                                                 {     // echo "Greater amount is = ".$greater_amount;
                                                      $sum = $amount - $money;

                                                      $query = "UPDATE user_account SET amount ='$sum' WHERE id =$id ";
                                                      $result = mysqli_query($con,$sql);
                                                     // echo"Amount is =".$amount;
                                                      // update for money
                                                      $query = "UPDATE user_account SET amount ='$money' WHERE id =$rid ";
                                                      $result = mysqli_query($con,$sql);
                                                      // echo"<script>alert.( ROW_AMOUNT is Successfully)</script>";
                                                      echo"<script>alert.'Money sended Done'</script>";
                                                      //echo " / n money is =".$amount;

                                                 }
                                                else
                                                {
                                                    $sum = $amount - $money;

                                                    $query = "UPDATE user_account SET amount ='$sum' WHERE id =$id ";
                                                    $result = mysqli_query($con,$sql);
                                                  
                                                    $query = "INSERT INTO user_account (id,amount) values('$rid','$money')";
                                                    $result = mysqli_query($con,$sql);
                                                    //echo"<script>alert.(ROW_AMOUNT is  Successfully)</script>";
                                                    echo " Insert Successfully";
                                                }
                                               
                                            }

                            }

            } // close the $perent row
            else
            {
                echo " Email Not Exist";
            }



}



?>