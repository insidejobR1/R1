<?php
// if session not set so start a session
if(!isset($_SESSION)) // yani seesion set hoga to hi session start hoga varna nhi hoga
{ 
  session_start(); 
} 
$id = "";
//Checking Session
//require_once('session_check.php');

// include database Show User Detail 
include ('config1.php');

/// traansection
// Turn off error reporting
error_reporting(0);
// last date 
$from_date = $_GET['from_date'];
// current date
$to_date = $_GET['to_date'];
// user table se created_at name ke time se late day se today tk ka data find kiya 
//$query = "SELECT * FROM users WHERE created_at BETWEEN '$from_date' AND '$to_date' ";
$query = "SELECT * FROM user_account WHERE date BETWEEN '$from_date' AND '$to_date' ";
$query_run = mysqli_query($con, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>Document</title>
    <link rel="stylesheet" href="sy.css">
</head>
<body>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card mt-5">
                    <div class="card-header">
                        <h4>Transection Record</h4>
                    </div>
                    <div class="card-body">
                    
                        <form action="" method="GET">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>From Date</label>
                                        <input type="date" name="from_date" value="" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>To Date</label>
                                        <input type="date" name="to_date" value="" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Click to Filter</label> <br>
                                        <button type="submit" class="btn btn-primary">Filter</button>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                      <div class="col-md-12">
                                      <div class="form-group">
                                      <label>Show Data by condition</label> <br>
                                     
                                      <a href="find_data/today.php" target="_blank" class="btn btn-sm btn-primary">Today</a>
                                      <a href="find_data/week.php" target="_blank" class="btn btn-sm btn-primary">Week</a>
                                      <a href="find_data/month.php"  target="_blank" class="btn btn-sm btn-primary">Month</a>
                                      <a href="find_data/3month.php" target="_blank" class="btn btn-sm btn-primary">3 Month</a>
                                      <a href="find_data/6month.php" target="_blank" class="btn btn-sm btn-primary">6 Month</a>
                                    
                  </div>
                </div>
              </div>
                        </form>
                    </div>
                </div>

                <div class="card mt-4">
                    <div class="card-body">
                        <?php
                        // All query Data show  
                        // find row number
                            if(mysqli_num_rows($query_run) > 0) {
                        ?>
                         <table class="table table-borderd">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th> Name</th>
                                    <th>Amount</th>
                                    <th>Email</th>
                                    <th>Date</th>
                                </tr>
                                <?php
                                $i=0;
                                // row me jo dta h use fagtch karke data h
                                while($row = mysqli_fetch_array($query_run)){
                                ?>
                                <tr>
                                    
                                    <td><?php echo $row["id"]; ?></td>
                                    <td><?php echo $row["name"]; ?></td>
                                    <td><?php echo $row["amount"]; ?></td>
                                    <td><?php echo $row["email"]; ?></td>
                                    <td><?php echo $row["date"]; ?></td>
                                </tr>
                                <?php
                                  $i++;
                                }
                                ?>
                            </thead>
                            <tbody>
                            
        
                            </tbody>
                        </table>
                        <?php
                            }
                          else{
                                echo "No result found";
                             }
                            
                        ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
    
    <!-- Deposit data-->
<div class="container">
<table class="table" >
  <thead class="thead-dark">
    <tr>
      <th scope="col">S.No.</th>
      <th scope="col">Amount</th>
      
      <th scope="col">Date</th>
    </tr>
  </thead>
  <tbody>
      <?php
      
    $sql = "select * from user_account";
      $res = mysqli_query($con,$sql);
      
      $row = mysqli_num_rows($res);
      
      echo $row;
     
      if($row >0)
      {
          //echo $row;
          while($ro = mysqli_fetch_assoc($res))
          { 
              $id = $ro['id'];
             // $name = $ro['name'];
              $amount = $ro['amount'];
            //   $email = $ro['email'];
            //   $pass = $ro['pass'];
            //   $add = $ro['addres'];
            //   $pan = $ro['pancard'];
            //   $adc = $ro['adharcard'];
              $date = $ro['date'];
              
              echo '<tr>
              <th scope="row">'.$id.'</th>
              <td>'. $amount.'</td>
            //  <td>'. $num.'</td>
            //   <td>'. $email.'</td>
            //   <td>'. $pass.'</td>
            //   <td>'. $add.'</td>
            //   <td>'. $pan.'</td>
            //   <td>'. $adc.'</td>
              <td>'. $date.'</td>
            
           </tr> ';
     
          }
        }
      

      ?>
    
  </tbody>
</table>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
</body>
</html>