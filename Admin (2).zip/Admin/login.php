<?php 
session_start();
include ('config1.php');
// master file
 include('master.php');

?> 

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
  <title>Deposit</title>
<!-- Bostrap css -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
   <!-- css -->

   <style>
     .panrl{
       position: relative;
     }

     .login{
       position: absolute;
       top: 50%;
       left: 50%;
       transform: translate(-50%,-50%);
     }

   </style>
  
</head>

<body>

<div class="container">
<!-- <h4>Add Amount</h4> -->
<form class="login" action="code.php" method="POST">
      <div class="modal-body">
          <h3>Login Form</h3>
               <div class="form-group">
          <label for="">Email</label>
          <input type="email" class="form-control" name="email" placeholder="Enter Email" >
        </div>
        <div class="form-group">
          <label for="">Password</label>
          <input type="password" class="form-control" name="pass" placeholder="Enter Password" >
        </div>
        <button type="submit" name="log" class="btn btn-primary col-lg">Login</button>

      </div>
      </form>
  </div> 
  
</body>
</html>