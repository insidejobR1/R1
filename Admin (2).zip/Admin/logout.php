<?php
session_start();
session_unset();
session_destroy();


//header("location:../signup/signup.php");
 echo "<script>  
          alert('Logout Successfully');
          location.assign('../signup/signup.php');
       </script>";
 
//header("location:../index.php");
//header("location:login.php");
//ob_end_flush(); 
//include 'masternew.php';
//include 'home.php';
exit();

?>