<?php
// connect to the connection
include ('config1.php');
// Update 
$id= $_GET['updateid'];
$sql  = "select * from register_tb where id = $id";
$res = mysqli_query($con, $sql);

$ro = mysqli_fetch_assoc($res);
              $id = $ro['id'];
              $name = $ro['name'];
              $number = $ro['number'];
              $email = $ro['email'];
              $pass = $ro['pass'];
              $add = $ro['address'];
               $pan = $ro['pancard'];
               $adc = $ro['adharcard'];
              $date = $ro['date'];
        
// for update data button
if(isset($_POST['up']))
{
    $id = $_GET['updateid'];
    $name = $_POST['name'];
    $number = $_POST['number'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $add = $_POST['add'];
    $pan = $_POST['pan'];
    $adc = $_POST['adhar'];
    $date = $_POST['dat'];

    $sql = "update register_tb set name='$name', number = '$number', email = '$email', pass='$pass', address = '$add', pancard= '$pan', adharcard = '$adc', date = '$date' where id ='$id'";
    $result = mysqli_query($con,$sql);

    if($result)
    {
        echo" Update Data ";
    }
    else
    {
        echo"Error";
    }

}
//$con.close();
mysqli_close($con);






?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>All Records of Student </title>
    <link rel="stylesheet" href="st.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 ">
                <form action="" method="POST">
                     <div class="form-group">
                        <label for="exampleInputName">Name</label>
                        <input type="text" class="form-control" id="exampleInputName" name="name" value="<?php  echo $name;?>" aria-describedby="nameHelp">
                        
                    </div>
                    <div class="form-group">
                        <label for="exampleInputNumber">Number</label>
                        <input type="number" class="form-control" id="exampleInputNumber" name="number" value="<?php  echo $number;?>" aria-describedby="numberHelp">
                    </div>
                    
                    <div class="form-group">
                        <label for="exampleInputEmail">Email</label>
                        <input type="email" class="form-control" id="exampleInputEmail" name="email" value="<?php  echo $email;?>" aria-describedby="emailHelp">

                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword" name="pass" value="<?php  echo $pass;?>">
                    </div>
                     <div class="form-group">
                        <label for="exampleInputNumber">Address</label>
                        <input type="textarea" class="form-control" id="exampleInputNumber" name="add" value="<?php  echo $add;?>" aria-describedby="numberHelp">
                    </div>
                     <div class="form-group">
                        <label for="exampleInputNumber">Pancred</label>
                        <input type="text" class="form-control" id="exampleInputNumber" name="pan" value="<?php  echo $pan;?>" aria-describedby="numberHelp">
                    </div>
                     <div class="form-group">
                        <label for="exampleInputNumber">Date</label>
                        <input type="date" class="form-control" id="exampleInputNumber" name="adhar" value="<?php  echo $dat;?>" aria-describedby="numberHelp">
                    </div>
                     <div class="form-group">
                        <label for="exampleInputNumber">Date</label>
                        <input type="date" class="form-control" id="exampleInputNumber" name="dat" value="<?php  echo $num;?>" aria-describedby="numberHelp">
                    </div>
                   
                   
                   
                   
                    <button type="submit" class="btn btn-info" name="up">Update</button>

                </form>

            </div>
        </div>
    </div>

</body>


</html>