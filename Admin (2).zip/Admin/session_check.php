<?php


session_start();
$email = $_SESSION['email'];
$uname = $_SESSION['uname'];

// if(!isset($email) || isset($uname)){
//     header('location:index.php');
// }




?>