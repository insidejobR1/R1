<?php
// if session not set so start a session
if (!isset($_SESSION)) 
{
  session_start();
}
$id = "";
// Turn off error reporting
error_reporting(0);
include('../config1.php');

 // current date
 $to_date = $_GET['to_date'];
 $sql = "select * from register_tb where  `date` >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)";
 //$sql = "select * from reg_tb order by id desc limit 20 ";
 //$sql = "select * from users where  `created_at` >= DATE_SUB(CURDATE(), INTERVAL 10 DAY)";
 $res = mysqli_query($con, $sql);

               
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">

  <link rel="stylesheet" href="sy.css">
</head>

<body>

  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card mt-5">
          <div class="card-header">
            <h4>Today Data Show</h4>
          </div>
          <div class="card-body">

            <form action="" method="GET">
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label>From Date</label>
                    <!-- <input type="date" name="from_date" value="" class="form-control"> -->
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>To Date</label>
                    <input type="date" name="to_date" value="" class="form-control">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>Click to Filter</label> <br>
                    <button type="submit" class="btn btn-primary">Filter</button>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Show Data by condition</label> <br>
                    <a href="./today.php" target="_blank" class="btn btn-sm btn-primary">Today</a>
                    
                    <a href="./week.php" target="_blank" class="btn btn-sm btn-primary">Week</a>
                    <a href="./month.php" target="_blank" class="btn btn-sm btn-primary">Month</a>
                    <a href="./3month.php" target="_blank" class="btn btn-sm btn-primary">3 Month</a>
                    <a href="./6month.php" target="_blank" class="btn btn-sm btn-primary">6 Month</a>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>

        <div class="card mt-4">
          <div class="card-body">
            <table class="table table-borderd">
              <thead>
                <tr>
                  <th scope="col">S.No.</th>
                  <th scope="col">User Name</th>
                  <th scope="col">Number</th>
                  <th scope="col">Email</th>
                  <th scope="col">Password</th>
                  <th scope="col">Address</th>
                  <th scope="col">Pancard</th>
                  <th scope="col">Adhar Number</th>
                  <th scope="col">Date</th>
                </tr>
              </thead>
              <tbody>
                <?php

                $row = mysqli_num_rows($res);

                echo "Total Customer " . $row;

                if ($row > 0) {
                  // echo "total<br>". $row;
                  while ($ro = mysqli_fetch_assoc($res)) {
                    $id = $ro['id'];
                    $name = $ro['name'];
                    $number = $ro['number'];
                    $email = $ro['email'];
                    $pass = $ro['pass'];
                    $add = $ro['address'];
                    $pan = $ro['pancard'];
                    $adc = $ro['adharcard'];
                    $date = $ro['date'];
                    echo '<tr>
                                <th scope="row">' . $id . '</th>
                                <td>' . $name . '</td>
                                <td>' . $number . '</td>
                                <td>' . $email . '</td>
                                <td>' . $pass . '</td>
                                <td>' . $add . '</td>
                                <td>' . $pan . '</td>
                               <td>' . $adc . '</td>
                                <td>' . $date . '</td>
                        </tr> ';
                 }
                ?>
              </tbody>
            </table>
          <?php
                } else {
                  echo "No result found";
                }
          ?>
          </div>
        </div>

      </div>
    </div>
  </div>
 
</body>
</html>