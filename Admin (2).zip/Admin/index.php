<?php
// if session not set so start a session
if(isset($_SESSION)) // yani seesion set hoga to hi session start hoga varna nhi hoga
{ 
  session_start(); 
} 

// session_start();
// $s_email = $_SESSION['email'];

// if(isset($s_email)){
//     header('location:dashbord.php');
// }

// include database Show User Detail 
include ('config1.php');
// login id pass by session
$id = $_SESSION['id']; 
// chack the user amount 
$query = "SELECT email from register_tb WHERE id= '$id'";
$result = mysqli_query($con,$query);
$row = mysqli_fetch_array($result);
$email = $row['email'];
//echo $email;
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Megrim&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
  <title>Document</title>
  <link rel="stylesheet" href="css/st.css">
</head>

<body>
  <section class="dashboard">
    <div class="navigation">
      <div class="brand">Capital Octa</div>
      <div class="nav-links">
        <ul class="nav-links-wrapper">
          <li><a href="index.php" style="color:azure;">Home</a></li>
          <li><a href="dashboard.php" style="color:azure;" >Dashboard</a></li>
          <li> <a href="fund.php" style="color:azure;">Fund </a></li>
          <li><a href="logout.php" style="color:azure;">Logout</a></li>
        </ul>
      </div>
    </div>

    <div class="wrapper">
      <!--       SIDEBAR -->
      <div class="sidebar">
        <img src="https://images.pexels.com/photos/10402422/pexels-photo-10402422.jpeg?cs=srgb&dl=pexels-wendel-moretti-10402422.jpg&fm=jpg" alt="profile-picture" class="side-img">
        <h2 class="author">CapitalOcta User</h2>
        <h2><?php echo $email;?></h2>
        <div class="elements">
          <ul class="el-wrapper">
            <li> <a href="dashboard.php">Dashboard </a></li>
            <li> <a href="deposit.php"> Deposit </a> </li>
            <li><a href="withdraw.php">Withdraw</a></li>
            <li><a href="transfer.php">Transfer</a></li>
            <li><a href="transation.php">Transactions</a></li>
            <li><a href="balance.php">Balance</a></li>
            <li><a href="show_all.php">Records</a></li>
            <li><a href="settings.php">Settings</a></li>
                <!--<li><a href="login.php">Login</a></li>-->
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div>
      </div>

      <!--       CONTENT-SECTION -->
      <div class="content-section">
        <div class="contents">CONTENTS
        <?php
// session display and unset code
//if(isset($_SESSION['success']) || isset($_SESSION['status']))
if(isset($_SESSION['success']))
{
  echo "<h3> ".$_SESSION['success']. "</h3>";
  unset($_SESSION['success'] ); // sesstion unset
}
elseif(isset($_SESSION['status']))
{
  echo "<h3> ".$_SESSION['status']. "</h3>";
  unset($_SESSION['status'] ); // sesstion unset
}
elseif(isset($_SESSION['uname']))
{
  echo "<h3>".$_SESSION['id']."</h3>"; 
  echo "<h3> Welcome ".$_SESSION['uname']."</h3>"; 
  ///echo $id;
}
elseif(isset($_SESSION['email']))
{
  echo "<h3>".$_SESSION['id']."</h3>"; 
  echo "<h3>Welcome ".$_SESSION['email']."</h3>"; 
}
?>

        </div>
        
      </div>
    </div>
  </section>
  <?php // session_unset();
  //unset($_SESSION['success']);
  //unset($_SESSION['status']);
  ?>
</body>

</html>