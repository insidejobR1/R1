<?php
$conn =  mysqli_connect("localhost", "root", "","userdetails") or die('Failed');

?>
