<?php
// SET HEADER
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: PUT");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");


$data = json_decode(file_get_contents("php://input"), true);
require_once "confi.php";
$pid = $data["id"];
$image = $data["image"];
$image_name = round(microtime(true) * 1000). ".jpg"; //Giving new name to image.
	        $img ="https://aoneservice.net.in/app_api/images/".round(microtime(true) * 1000). ".jpg";

	        $image_upload_dir =$_SERVER['DOCUMENT_ROOT'].'/app_api/images/'.$image_name; //Set the path where we need to upload the image.

                
	        $flag = file_put_contents($image_upload_dir, base64_decode($image));



 $query = "UPDATE register SET image='".$img."'
                              
                           WHERE id='".$pid."' ";

if(mysqli_query($con, $query))
{ 
 echo json_encode(array("message" => "Product Update Successfully", "status" => true)); 
}
else
{ 
 echo json_encode(array("message" => "Failed Product Not Updated", "status" => false)); 
}

?>