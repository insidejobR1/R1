<?php
$server="localhost";
$name="aoneserv_ani";
$password="Anirudh123@";
$db="aoneserv_FairDeal";
$con=mysqli_connect($server,$name,$password,$db);

$post_id = filter_var($_GET['id'], FILTER_VALIDATE_INT,[
        'options' => [
            'default' => 'all_posts',
           
        ]
    ]);
$select_query="select policy,starting_date,scheme_amount,last_date from form where user_id=$post_id";
$connect=mysqli_query($con,$select_query);
$count=mysqli_num_rows($connect);
header('Content-type:application/json');

if($count>0){
while($row=mysqli_fetch_assoc($connect)){
$arr[]=$row;
}
echo json_encode($arr);
}
else{
echo json_encode('no data found');
}


?>