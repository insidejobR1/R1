

<?php
include 'confi.php'; //database connection code

error_reporting(0);
$postData = file_get_contents('php://input'); //collect inout parameters
$postData = json_decode($postData,true); //convert into readable format

// echo '<pre>';
// print_r($postData);
// echo '</pre>';

        $name=$postData['name'];
        $email=$postData['email'];
        $phone=$postData['phone'];
        $password=$postData['password'];
        $referral=$postData['referral'];



		$image = $postData['image'];

    
 //This a postdata here we going to collect the base64 image.
		if (strlen($image) > 0) {
		
		 //declaring the image name variable
	 //Set the validation that if image lenght must be greater than 0. So image is in base64 so it will be in string
			
	        $image_name = round(microtime(true) * 1000). ".jpg"; //Giving new name to image.
	        $img ="https://aoneservice.net.in/app_api/image/". round(microtime(true) * 1000). ".jpg";

	        $image_upload_dir =$_SERVER['DOCUMENT_ROOT'].'/app_api/image/'.$image_name; //Set the path where we need to upload the image.

                
	        $flag = file_put_contents($image_upload_dir, base64_decode($image));
	        //Here is the main code to convert Base64 image into the real image/Normal image.
	        //file_put_contents is function of php. first parameter is the path where you neeed to upload the image. second parameter is the base64image and with the help of base64_decode function we decoding the image.
 //Basically flag variable is set for if image get uploaded it will give us true then we will save it in database or else we give response for fail.

	    $qry2 = mysqli_query($con,'INSERT into register_image (id,name,email,phone,password,referral,image) VALUES("","'.$name.'","'.$email.'","'.$phone.'","'.$password.'","'.$referral.'","'.$img.'")');
	        
				$res['status'] = 'success';
				$res['message'] = 'Base64 image uploaded';

				//So lets try to upload image via postman
				}else{
				   $image_name = round(microtime(true) * 1000). ".jpg"; //Giving new name to image.
	        $img ="https://aoneservice.net.in/app_api/image/". round(microtime(true) * 1000). ".jpg";

	        $image_upload_dir =$_SERVER['DOCUMENT_ROOT'].'/app_api/image/'.$image_name; //Set the path where we need to upload the image.

                
	        $flag = file_put_contents($image_upload_dir, base64_decode($image));
	        //Here is the main code to convert Base64 image into the real image/Normal image.
	        //file_put_contents is function of php. first parameter is the path where you neeed to upload the image. second parameter is the base64image and with the help of base64_decode function we decoding the image.
 //Basically flag variable is set for if image get uploaded it will give us true then we will save it in database or else we give response for fail.

	    $qry2 = mysqli_query($con,'INSERT into register_image (id,name,email,phone,password,referral) VALUES("","'.$name.'","'.$email.'","'.$phone.'","'.$password.'","'.$referral.'")');
	        	
				$res['status'] = 'success';
				$res['message'] = 'Base64 image uploaded';

				}
	       
	  
	    echo json_encode($res); //all API response send from here
	    ?>