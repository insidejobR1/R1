<?php
// SET HEADER
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");

// INCLUDING DATABASE AND MAKING OBJECT
require 'databasess.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// CHECK GET ID PARAMETER OR NOT
if(isset($_GET['id']))
{
    //IF HAS ID PARAMETER
    $post_id = filter_var($_GET['id'], FILTER_VALIDATE_INT,[
        'options' => [
            'default' => 'all_posts',
           
        ]
    ]);
}
else{
    $post_id = 'all_posts';
}

// MAKE SQL QUERY
// IF GET POSTS ID, THEN SHOW POSTS BY ID OTHERWISE SHOW ALL POSTS
$sql = is_numeric($post_id) ? "SELECT * FROM `properties`,`properties_images` WHERE properties.id=properties_images.properties_id and properties.id='$post_id' limit 1" : "SELECT * FROM `properties`,`properties_images` where properties.id=properties_images.properties_id limit 1"; 

$stmt = $conn->prepare($sql);

$stmt->execute();

//CHECK WHETHER THERE IS ANY POST IN OUR DATABASE
if($stmt->rowCount() > 0){
    // CREATE POSTS ARRAY
    $posts_array = [];
    
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        
        $post_data = [
            'id' => $row['id'],
            'description' => $row['description'],
            'location' => $row['location'],
              'status' => $row['status'],
              'bhk'=> $row['bhk'],
              'facing'=> $row['facing'],
              'furnishing_status'=> $row['furnishing_status'],
              'likes'=>$row['likes'],
              'views'=>$row['views'],
           'category'=> $row['category'],
           'project_id'=> $row['project_id'],
                 'date' => $row['date'],
                   'name' => $row['name'],
                     'carpet_area' => $row['carpet_area'],
                     'images' => $row['images'],
                     'total_area'=> $row['total_area'],
        ];
        // PUSH POST DATA IN OUR $posts_array ARRAY
        array_push($posts_array, $post_data);
    }
    //SHOW POST/POSTS IN JSON FORMAT
    echo json_encode($posts_array);
 

}
else{
    //IF THER IS NO POST IN OUR DATABASE
    echo json_encode(['message'=>'No post found']);
}
?>