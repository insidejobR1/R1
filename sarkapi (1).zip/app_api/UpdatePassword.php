<?php
// SET HEADER
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// INCLUDING DATABASE AND MAKING OBJECT
require 'databasess.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FORM REQUEST
$data = json_decode(file_get_contents("php://input"));

//CREATE MESSAGE ARRAY AND SET EMPTY
$msg['message'] = '';

 $post_id = filter_var($_GET['phone'], FILTER_VALIDATE_INT,[
        'options' => [
            'default' => 'all_posts',
           
        ]
    ]);

// CHECK IF RECEIVED DATA FROM THE REQUEST

    // CHECK DATA VALUE IS EMPTY OR NOT
   
        
        $insert_query = "UPDATE register SET password=:password WHERE phone = $post_id";
        
        $insert_stmt = $conn->prepare($insert_query);
        // DATA BINDING
        $insert_stmt->bindValue(':password', htmlspecialchars(strip_tags($data->password)),PDO::PARAM_STR);
        if($insert_stmt->execute()){
            $msg['message'] = 'Data Updated Successfully';
        }else{
            $msg['message'] = 'Data not Updated';
        } 
        
   


//ECHO DATA IN JSON FORMAT
echo  json_encode($msg);
?>