<?php
// SET HEADER
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// INCLUDING DATABASE AND MAKING OBJECT
require 'databasess.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FORM REQUEST
$data = json_decode(file_get_contents("php://input"));
$post_id = $_GET['employee_id'];
$post_lat = $_GET['latitude'];
$post_long = $_GET['longitude'];
$datetime = $_GET['datetime'];

$date = substr($datetime,0,10);
$time = substr($datetime,10);

//CREATE MESSAGE ARRAY AND SET EMPTY
$msg['message'] = '';

// CHECK IF RECEIVED DATA FROM THE REQUEST

    // CHECK DATA VALUE IS EMPTY OR NOT
    
    $sql = "SELECT * FROM `register`  WHERE id='$post_id'"; 
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $sub_plat = substr($post_lat,0,9);
    $sub_plong = substr($post_long,0,9);
    
    $row_lat = substr($row['assign_latitude'],0,9);
    $row_long = substr($row['assign_longitude'],0,9);
    
    if($sub_plat==$row_lat && $sub_plong==$row_long ){
        $insert_query = "INSERT INTO `attendance` (date,time,user_id) VALUES('$date','$time',:employee_id)";
        $insert_stmt = $conn->prepare($insert_query);
    }
    
    
   
        
        $insert_query = "INSERT INTO `location` (latitude,longitude,employee_id,datetime) VALUES(:latitude,:longitude,:employee_id,:datetime)";
        
        $insert_stmt = $conn->prepare($insert_query);
        // DATA BINDING
        $insert_stmt->bindValue(':latitude', htmlspecialchars(strip_tags($data->latitude)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':longitude', htmlspecialchars(strip_tags($data->longitude)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':employee_id', htmlspecialchars(strip_tags($data->employee_id)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':datetime', htmlspecialchars(strip_tags($data->datetime)),PDO::PARAM_STR);
       
        
        if($insert_stmt->execute()){
            $msg['message'] = 'Data Inserted Successfully';
        }else{
            $msg['message'] = 'Data not Inserted';
        } 
        
   


//ECHO DATA IN JSON FORMAT
echo  json_encode($msg);
?>