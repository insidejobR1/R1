<?php
// SET HEADER
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: DELETE");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// INCLUDING DATABASE AND MAKING OBJECT
require 'databasess.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FORM REQUEST
$data = json_decode(file_get_contents("php://input"));


//CHECKING, IF ID AVAILABLE ON $data

    //IF HAS ID PARAMETER
    $id = filter_var($_GET['id'], FILTER_VALIDATE_INT,[
        'options' => [
            'default' => 'all_posts',
           
        ]
    ]);
    
     $like = filter_var($_GET['like'], FILTER_VALIDATE_INT,[
        'options' => [
            'default' => 'all_posts',
           
        ]
    ]);

    
 
    //CHECK WHETHER THERE IS ANY POST IN OUR DATABASE
   
        
        //DELETE POST BY ID FROM DATABASE
        $update_post = "UPDATE properties SET likes='$like' WHERE id='$id'";
        $update_post_stmt = $conn->prepare($update_post);
        if($update_post_stmt->execute()){
            $msg['message'] = 'Post Updated Successfully';
        }else{
            $msg['message'] = 'Post Not Updated';
        }
        
   
    // ECHO MESSAGE IN JSON FORMAT
    echo  json_encode($msg);
    

?>