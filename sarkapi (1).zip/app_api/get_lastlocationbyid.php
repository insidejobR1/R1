<?php
header('Content-type:application/json');

$server="localhost";
$name="aoneserv_ani";
$password="Anirudh123@";
$db="aoneserv_test";
$con=mysqli_connect($server,$name,$password,$db);

$data = json_decode(file_get_contents("php://input"));
if(isset($_GET['id']))
{
    //IF HAS ID PARAMETER
    $post_id = filter_var($_GET['id'], FILTER_VALIDATE_INT,[
        'options' => [
            'default' => 'all_posts',
           
        ]
    ]);
}
else{
    $post_id = 'all_posts';
}


$select_query="SELECT * FROM location JOIN register ON  register.id=location.employee_id WHERE register.id ='$post_id' AND datetime IN (
                                                                                                SELECT MAX(datetime)
                                                                                                FROM location GROUP BY location.employee_id
                                                                                                )";
$connect=mysqli_query($con,$select_query);
$count=mysqli_num_rows($connect);


if($count>0){
while($row=mysqli_fetch_assoc($connect)){

$arr[]=$row;

    
}

echo json_encode($arr);
}
else{
     $error[] = array("name"=>"No data Found");
echo json_encode($error);
}


?>