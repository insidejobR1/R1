 <?php
 $con = mysqli_connect("localhost", "aoneserv_ani", "Anirudh123@", 'aoneserv_test');
 ?>