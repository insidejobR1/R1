<?php
// SET HEADER
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: DELETE");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// INCLUDING DATABASE AND MAKING OBJECT
require 'databasess.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FORM REQUEST
$data = json_decode(file_get_contents("php://input"));


//CHECKING, IF ID AVAILABLE ON $data

    //IF HAS ID PARAMETER
    $user_id = filter_var($_GET['user_id'], FILTER_VALIDATE_INT,[
        'options' => [
            'default' => 'all_posts',
           
        ]
    ]);
    
     $property_id = filter_var($_GET['property_id'], FILTER_VALIDATE_INT,[
        'options' => [
            'default' => 'all_posts',
           
        ]
    ]);

    
 
    //CHECK WHETHER THERE IS ANY POST IN OUR DATABASE
   
        
        //DELETE POST BY ID FROM DATABASE
        $select_post="delete from Recents where property_id='$property_id' and user_id='$user_id'";
        $select_post_stmt = $conn->prepare($select_post);
        $select_post_stmt->execute();
        $delete_post = "Insert into `Recents` (property_id,user_id) values('$property_id','$user_id')";
        $delete_post_stmt = $conn->prepare($delete_post);
        if($delete_post_stmt->execute()){
            $msg['message'] = 'Post inserted Successfully';
        }else{
            $msg['message'] = 'Post Not inserted';
        }
        
   
    // ECHO MESSAGE IN JSON FORMAT
    echo  json_encode($msg);
    

?>