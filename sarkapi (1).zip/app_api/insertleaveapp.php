<?php
// SET HEADER
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// INCLUDING DATABASE AND MAKING OBJECT
require 'databasess.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FORM REQUEST
$data = json_decode(file_get_contents("php://input"));

//CREATE MESSAGE ARRAY AND SET EMPTY
$msg['message'] = '';

// CHECK IF RECEIVED DATA FROM THE REQUEST

    // CHECK DATA VALUE IS EMPTY OR NOT
   
        
        $insert_query = "INSERT INTO `leavee`(title,leave_description,start_date,end_date,status,emp_id) VALUES(:title,:leave_description,:start_date,:end_date,:status,:emp_id)";
        
        $insert_stmt = $conn->prepare($insert_query);
        // DATA BINDING
     
         $insert_stmt->bindValue(':title', htmlspecialchars(strip_tags($data->title)),PDO::PARAM_STR);
       
        $insert_stmt->bindValue(':leave_description', htmlspecialchars(strip_tags($data->leave_description)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':start_date', htmlspecialchars(strip_tags($data->start_date)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':end_date', htmlspecialchars(strip_tags($data->end_date)),PDO::PARAM_STR);
     
           $insert_stmt->bindValue(':status', htmlspecialchars(strip_tags($data->status)),PDO::PARAM_STR);
           
         $insert_stmt->bindValue(':emp_id', htmlspecialchars(strip_tags($data->emp_id)),PDO::PARAM_STR);
        
        if($insert_stmt->execute()){
            $msg['message'] = 'Data Inserted Successfully';
        }else{
            $msg['message'] = 'Data not Inserted';
        } 
        
   

//ECHO DATA IN JSON FORMAT
echo  json_encode($msg);
?>