<?php
header('Content-type:application/json');

$NUM[] = array("number"=>"8821099922","start"=>"20:00:00","end"=>"22:00:00");
echo json_encode($NUM);

?>