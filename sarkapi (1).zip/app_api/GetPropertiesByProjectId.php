<?php
$server="localhost";
$name="aoneserv_ani";
$password="Anirudh123@";
$db="aoneserv_test";
$con=mysqli_connect($server,$name,$password,$db);


$id = filter_var($_GET['id'], FILTER_VALIDATE_INT,[
        'options' => [
            'default' => 'all_posts',
           
        ]
    ]);

$select_query="select * from properties where project_id='$id'";
$connect=mysqli_query($con,$select_query);
$count=mysqli_num_rows($connect);
header('Content-type:application/json');

if($count>0){
while($row=mysqli_fetch_assoc($connect)){
    $select_query_image ="select images from properties_images where properties_id= '$row[id]'";
    $connectimage=mysqli_query($con,$select_query_image);
    $row1=mysqli_fetch_assoc($connectimage);
    $row['image'] = $row1['images'];
$arr[]=$row;
}
// $row=mysqli_fetch_assoc($connect);
// $arr[]=$row;
echo json_encode($arr);
}
else{
echo json_encode('no data found');
}


?>