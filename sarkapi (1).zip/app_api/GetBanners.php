<?php
$server="localhost";
$name="aoneserv_ani";
$password="Anirudh123@";
$db="aoneserv_test";
$con=mysqli_connect($server,$name,$password,$db);


$select_query="select * from Banners";
$connect=mysqli_query($con,$select_query);
$count=mysqli_num_rows($connect);
header('Content-type:application/json');

if($count>0){
while($row=mysqli_fetch_assoc($connect)){
$arr[]=$row;
}
echo json_encode($arr);
}
else{
echo json_encode('no data found');
}


?>