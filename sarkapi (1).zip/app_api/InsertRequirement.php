<?php
// SET HEADER
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// INCLUDING DATABASE AND MAKING OBJECT
require 'databasess.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FORM REQUEST
$data = json_decode(file_get_contents("php://input"));

//CREATE MESSAGE ARRAY AND SET EMPTY
$msg['message'] = '';

// CHECK IF RECEIVED DATA FROM THE REQUEST

    // CHECK DATA VALUE IS EMPTY OR NOT
   
        
        $insert_query = "INSERT INTO `Requirements` (location,type,area_max,area_min,user_id) VALUES(:location,:type,:area_max,:area_min,:user_id)";
        
        $insert_stmt = $conn->prepare($insert_query);
        // DATA BINDING
        $insert_stmt->bindValue(':location', htmlspecialchars(strip_tags($data->location)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':type', htmlspecialchars(strip_tags($data->type)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':area_max', htmlspecialchars(strip_tags($data->area_max)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':area_min', htmlspecialchars(strip_tags($data->area_min)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':user_id', htmlspecialchars(strip_tags($data->user_id)),PDO::PARAM_STR);
        
        if($insert_stmt->execute()){
            $msg['message'] = 'Data Inserted Successfully';
        }else{
            $msg['message'] = 'Data not Inserted';
        } 
        
   


//ECHO DATA IN JSON FORMAT
echo  json_encode($msg);
?>