

<?php
include 'config.php'; //database connection code

error_reporting(0);
$postData = file_get_contents('php://input'); //collect inout parameters
$postData = json_decode($postData,true); //convert into readable format

// echo '<pre>';
// print_r($postData);
// echo '</pre>';


        $father_name = $postData['father_name'];
        $gender=$postData['gender'];
        $dob=$postData['dob'];
        $address=$postData['address'];
        $city=$postData['city'];
        $state=$postData['state'];
        $pincode=$postData['pincode'];
        $nominee_name=$postData['nominee_name'];
        $nominee_father=$postData['nominee_father'];
        $nominee_relation=$postData['nominee_relation'];
        $nominee_dob=$postData['nominee_dob'];
        $gift_name=$postData['gift_name'];
        $gift_gender=$postData['gift_gender'];
        $gift_dob=$postData['gift_dob'];
        $gift_relation=$postData['gift_relation'];
        $scheme_term=$postData['scheme_term'];
        $scheme_amount=$postData['scheme_amount'];
        $mode=$postData['mode'];
        $referral_name=$postData['referral_name'];
        $user_id=$postData['user_id'];
        $policy=$postData['policy'];
        $starting_date=$postData['starting_date'];
        $last_date=$postData['last_date'];

		$applicant_photo = $postData['applicant_photo'];
			$nominee_photo = $postData['nominee_photo'];
				$photoId_front = $postData['photoId_front'];
					$photoId_back = $postData['photoId_back'];
		
		
	
     
        
 //This a postdata here we going to collect the base64 image.
	
		
		 //declaring the image name variable
	 //Set the validation that if image lenght must be greater than 0. So image is in base64 so it will be in string
			
	        $image_name1 = round(microtime(true) * 1000). ".jpg"; //Giving new name to image.
	           $image_name2 = round(microtime(true) * 2000). ".jpg"; 
	              $image_name3 = round(microtime(true) * 3000). ".jpg"; 
	                 $image_name4 = round(microtime(true) * 4000). ".jpg"; 
	        $img1 ="https://aoneservice.net.in/app_api/images/". round(microtime(true) * 1000). ".jpg";
	         $img2 ="https://aoneservice.net.in/app_api/images/". round(microtime(true) * 2000). ".jpg";
	          $img3 ="https://aoneservice.net.in/app_api/images/". round(microtime(true) * 3000). ".jpg";
	           $img4 ="https://aoneservice.net.in/app_api/images/". round(microtime(true) * 4000). ".jpg";

	        $image_upload_dir1 =$_SERVER['DOCUMENT_ROOT'].'/app_api/images/'.$image_name1; //Set the path where we need to upload the image.
	           $image_upload_dir2 =$_SERVER['DOCUMENT_ROOT'].'/app_api/images/'.$image_name2; //Set the path where we need to upload the image.
	              $image_upload_dir3 =$_SERVER['DOCUMENT_ROOT'].'/app_api/images/'.$image_name3; //Set the path where we need to upload the image.
	                 $image_upload_dir4 =$_SERVER['DOCUMENT_ROOT'].'/app_api/images/'.$image_name4; //Set the path where we need to upload the image.

                
	        $flag1 = file_put_contents($image_upload_dir1, base64_decode($applicant_photo));
	           $flag2 = file_put_contents($image_upload_dir2, base64_decode($nominee_photo));
	              $flag3 = file_put_contents($image_upload_dir3, base64_decode($photoId_front));
	                 $flag4 = file_put_contents($image_upload_dir4, base64_decode($photoId_back));
	        //Here is the main code to convert Base64 image into the real image/Normal image.
	        //file_put_contents is function of php. first parameter is the path where you neeed to upload the image. second parameter is the base64image and with the help of base64_decode function we decoding the image.
 //Basically flag variable is set for if image get uploaded it will give us true then we will save it in database or else we give response for fail.

	    $qry2 = mysqli_query($con,'INSERT into form (id,father_name, gender, dob, address, city, state, pincode, nominee_name, nominee_father,
        nominee_relation, nominee_dob, gift_name, gift_gender, gift_dob, gift_relation, scheme_term, scheme_amount, mode, referral_name,
        user_id,policy,starting_date,last_date,applicant_photo,nominee_photo,photoId_front,photoId_back) VALUES("","'.$father_name.'", "'.$gender.'", "'.$dob.'", "'.$address.'", "'.$city.'", "'.$state.'", "'.$pincode.'", "'.$nominee_name.'","'.$nominee_father.'","'.$nominee_relation.'", "'.$nominee_dob.'", "'.$gift_name.'", 
        "'.$gift_gender.'", "'.$gift_dob.'", "'.$gift_relation.'", "'.$scheme_term.'", "'.$scheme_amount.'", "'.$mode.'", "'.$referral_name.'", "'.$user_id.'","'.$policy.'","'.$starting_date.'","'.$last_date.'","'.$img1.'","'.$img2.'","'.$img3.'","'.$img4.'")');
	        	$res['data']['applicant_photo'] = $image_name1;
	        	$res['data']['nominee_photo'] = $image_name2;
	        	$res['data']['photoId_front'] = $image_name3;
	        	$res['data']['photoId_back'] = $image_name4;
				$res['status'] = 'success';
				$res['message'] = 'Base64 image uploaded';

				//So lets try to upload image via postman
			
	       
	  
	    echo json_encode($res); //all API response send from here
	    ?>