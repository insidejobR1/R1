<?php
$server="localhost";
$name="aoneserv_ani";
$password="Anirudh123@";
$db="aoneserv_test";
$con=mysqli_connect($server,$name,$password,$db);

$data = json_decode(file_get_contents("php://input"));
if(isset($_GET['id']))
{
    //IF HAS ID PARAMETER
    $post_id = filter_var($_GET['id'], FILTER_VALIDATE_INT,[
        'options' => [
            'default' => 'all_posts',
           
        ]
    ]);
}
else{
    $post_id = 'all_posts';
}
$post_datetimestart =$_GET['datetimestart'];


$post_datetimeend = $_GET['datetimeend'];

$select_query="SELECT * FROM location JOIN register ON  register.id=location.employee_id WHERE register.id ='$post_id' AND location.datetime >= '$post_datetimestart' AND location.datetime <= '$post_datetimeend' ";
//datetime > current_date - interval 7 day ORDER BY datetime DESC"


$connect=mysqli_query($con,$select_query);
$count=mysqli_num_rows($connect);
header('Content-type:application/json');

if($count>0){
while($row=mysqli_fetch_assoc($connect)){

$arr[]=$row;

    
}
// $row=mysqli_fetch_assoc($connect);
// $arr[]=$row;
echo json_encode($arr);
}
else{
echo json_encode('no data found');
}


?>