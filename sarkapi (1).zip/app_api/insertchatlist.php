 <?php

include_once('confi.php');

if($_SERVER['REQUEST_METHOD'] == "POST"){
$user_id = isset($_POST['user_id']) ? mysqli_real_escape_string($_POST['user_id']) : "";


// Insert data into data base
 $sql = "INSERT INTO chat_list ( user_id) VALUES ( '" . $user_id . "');";
 $qur = $conn->query($sql);
 if($qur){
 $json = array("status" => 1, "msg" => "Done User added!");
 }else{
 $json = array("status" => 0, "msg" => "Error adding user!");
 }
}else{
 $json = array("status" => 0, "msg" => "Request method not accepted");
}
mysqli_close($conn);


 



/* Output header */
 header('Content-type: application/json');
 echo json_encode($json);
?>