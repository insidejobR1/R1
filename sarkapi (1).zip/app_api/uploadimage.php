
text/x-generic uploadimage.php ( PHP script, ASCII text, with CRLF line terminators )
<?php
include 'confi.php'; //database connection code

error_reporting(0);
$postData = file_get_contents('php://input'); //collect inout parameters
$postData = json_decode($postData,true); //convert into readable format

if(empty($postData)){
	$postData = $_POST;
}
// echo '<pre>';
// print_r($postData);
// echo '</pre>';

		$image = $postData['image']; //This a postdata here we going to collect the base64 image.
		$image_name = ""; //declaring the image name variable
		if (strlen($image) > 0) { //Set the validation that if image lenght must be greater than 0. So image is in base64 so it will be in string
			
	        $image_name = round(microtime(true) * 1000). ".jpg"; //Giving new name to image.
	        $img ="https://aoneservice.net.in/app_api/images/". round(microtime(true) * 1000). ".jpg";

	        $image_upload_dir =$_SERVER['DOCUMENT_ROOT'].'/app_api/images/'.$image_name; //Set the path where we need to upload the image.


	        $flag = file_put_contents($image_upload_dir, base64_decode($image));
	        //Here is the main code to convert Base64 image into the real image/Normal image.
	        //file_put_contents is function of php. first parameter is the path where you neeed to upload the image. second parameter is the base64image and with the help of base64_decode function we decoding the image.

	        if($flag){ //Basically flag variable is set for if image get uploaded it will give us true then we will save it in database or else we give response for fail.

	        	$qry2 = mysqli_query($con,'INSERT into images (id,name) VALUES("","'.$img.'")');
	        	$res['data']['image'] = $image_name;
				$res['status'] = 'success';
				$res['message'] = 'Base64 image uploaded';

				//So lets try to upload image via postman
	        }else{
	        	$res['data'] = array();
				$res['status'] = 'fail';
				$res['message'] = 'Something wrong';
	        }
	        
	    }else{
	    	$res['data'] = array();
			$res['status'] = 'fail';
			$res['message'] = 'Please passed image';
	    }
	    echo json_encode($res); //all API response send from here
	    ?>